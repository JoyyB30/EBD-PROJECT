const mongoose = require('mongoose');

const userSchema = new mongoose.Schema(
  {
    username: { type: String, required: true },
    phone: { type: String, required: true, unique: true },
    nationalID: { type: String, required: true },
    password: { type: String, required: true }, // hashed password
    role: { type: String, default: 'farmer' }   // fixed, no options
  },
  { timestamps: true }
);

module.exports = mongoose.model('User', userSchema);