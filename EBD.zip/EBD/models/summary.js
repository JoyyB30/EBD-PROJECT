const mongoose = require('mongoose');

const summarySchema = new mongoose.Schema({
  farmerId: { type: String, required: true },                    // or ObjectId later
  type: { type: String, enum: ['income', 'expense'], required: true },
  amount: { type: Number, required: true },
  category: { type: String },
  date: { type: Date, required: true },
  description: { type: String },
});

module.exports = mongoose.model('Summary', summarySchema);