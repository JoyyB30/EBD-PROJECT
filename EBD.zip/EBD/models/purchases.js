const mongoose = require('mongoose');

const purchaseSchema = new mongoose.Schema({
  farmerId: {
    type: String,
    required: true,
  },
  supplier: {
    name: { type: String, required: true },
    phone: { type: String, required: true },
  },
  itemType: {
    type: String,
    required: true,
  },
  quantity: {
    type: Number,
    required: true,
  },
  unitPrice: {
    type: Number,
    required: true,
  },
  totalCost: {
    type: Number,
    required: true,
  },
  date: {
    type: Date,
    default: Date.now,
  },
});

module.exports = mongoose.model('Purchase', purchaseSchema);