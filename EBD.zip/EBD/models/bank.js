const mongoose = require('mongoose');

const supplierSchema = new mongoose.Schema({
    supplierID: {
        type: String,
        required: true,
        unique: true
    },
    name: {
        type: String,
        required: true,
        trim: true
    },
    phoneNumber: {
        type: String,
        required: true,
        unique: true
    },
    // You can add fields for loan requests later for the full implementation
});

// The model will be named 'Supplier' in MongoDB
const Supplier = mongoose.model('Supplier', supplierSchema);

// Export the model so the routes file can use it
module.exports = Supplier;