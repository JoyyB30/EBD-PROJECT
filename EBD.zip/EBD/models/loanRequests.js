const mongoose = require('mongoose');

const loanRequestSchema = new mongoose.Schema({
  farmerId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  nationalID: {
    type: String,
    required: true,
  },
  status: {
    type: String,
    enum: ['pending', 'approved', 'rejected'],
    default: 'pending',
  },
  approvedAmount: {
    type: Number,
    default: 0,
  },
  dateRequested: {
    type: Date,
    default: Date.now,
  },
});

module.exports = mongoose.model('LoanRequest', loanRequestSchema);