const express = require('express');
const LoanRequest = require('../models/loanRequests');

const router = express.Router();

/**
 * Create a new loan request
 * POST /api/loans
 */
router.post('/', async (req, res) => {
  try {
    console.log('POST /api/loans hit with body:', req.body);

    const { farmerId, nationalID, approvedAmount } = req.body;

    if (!farmerId || !nationalID) {
      return res.status(400).json({
        error: 'farmerId and nationalID are required',
      });
    }

    const loanRequest = new LoanRequest({
      farmerId,
      nationalID,
      approvedAmount: approvedAmount || 0,
    });

    const saved = await loanRequest.save();
    return res.status(201).json(saved);
  } catch (err) {
    console.error('Error creating loan request:', err);
    return res.status(500).json({ error: 'Server error' });
  }
});

/**
 * Get all loan requests
 * GET /api/loans
 */
router.get('/', async (req, res) => {
  try {
    const { farmerId, status } = req.query;
    const filter = {};

    if (farmerId) filter.farmerId = farmerId;
    if (status) filter.status = status;

    const loans = await LoanRequest.find(filter).sort({ dateRequested: -1 });
    return res.json(loans);
  } catch (err) {
    console.error('Error fetching loan requests:', err);
    return res.status(500).json({ error: 'Server error' });
  }
});

/**
 * Get single loan by ID
 * GET /api/loans/:id
 */
router.get('/:id', async (req, res) => {
  try {
    const loan = await LoanRequest.findById(req.params.id);

    if (!loan) {
      return res.status(404).json({ error: 'Loan request not found' });
    }

    return res.json(loan);
  } catch (err) {
    console.error('Error fetching loan request:', err);
    return res.status(500).json({ error: 'Server error' });
  }
});

/**
 * Update loan request
 * PUT /api/loans/:id
 */
router.put('/:id', async (req, res) => {
  try {
    const { status, approvedAmount } = req.body;

    const updateData = {};
    if (status) updateData.status = status;
    if (approvedAmount !== undefined) updateData.approvedAmount = approvedAmount;

    const updated = await LoanRequest.findByIdAndUpdate(
      req.params.id,
      updateData,
      { new: true }
    );

    if (!updated) {
      return res.status(404).json({ error: 'Loan request not found' });
    }

    return res.json(updated);
  } catch (err) {
    console.error('Error updating loan request:', err);
    return res.status(500).json({ error: 'Server error' });
  }
});

/**
 * Delete loan request
 * DELETE /api/loans/:id
 */
router.delete('/:id', async (req, res) => {
  try {
    const deleted = await LoanRequest.findByIdAndDelete(req.params.id);

    if (!deleted) {
      return res.status(404).json({ error: 'Loan request not found' });
    }

    return res.json({ message: 'Loan request deleted' });
  } catch (err) {
    console.error('Error deleting loan request:', err);
    return res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;