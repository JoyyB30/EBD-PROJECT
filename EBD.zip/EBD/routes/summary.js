const express = require('express');
const router = express.Router();
const Summary = require('../models/summary');

// CREATE summary record
router.post('/', async (req, res) => {
  try {
    const { farmerId, type, amount, category, date, description } = req.body;
    if (!farmerId || !type || !amount || !date) {
      return res.status(400).json({ message: 'Missing required fields' });
    }

    const summary = await Summary.create({
      farmerId, type, amount, category, date, description
    });

    res.status(201).json(summary);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// READ SUMMARY by farmer
router.get('/:farmerId', async (req, res) => {
  try {
    const records = await Summary.find({ farmerId: req.params.farmerId });
    res.json(records);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// UPDATE summary by ID
router.put('/:id', async (req, res) => {
  try {
    const updated = await Summary.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    );

    if (!updated) {
      return res.status(404).json({ message: 'Record not found' });
    }

    res.json(updated);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// DELETE summary by ID
router.delete('/:id', async (req, res) => {
  try {
    const deleted = await Summary.findByIdAndDelete(req.params.id);
    if (!deleted) {
      return res.status(404).json({ message: 'Record not found' });
    }

    res.json({ message: 'Deleted successfully', id: deleted._id });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;