const express = require('express');
const router = express.Router(); // Use 'router' consistently (lowercase 'r')
const Supplier = require('../models/bank'); // FIX 1: Corrected relative path

// 1. CREATE a new Supplier (POST /api/bank/suppliers)
router.post('/suppliers', async (req, res) => {
    try {
        const newSupplier = new Supplier(req.body);
        const savedSupplier = await newSupplier.save();
        res.status(201).json(savedSupplier);
    } catch (err) {
        // Handle validation errors (e.g., unique constraints)
        res.status(400).json({ message: err.message });
    }
});

// 2. READ ALL Suppliers (GET /api/bank/suppliers) - Fetch farmer records
router.get('/suppliers', async (req, res) => {
    try {
        const suppliers = await Supplier.find();
        res.json(suppliers);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// 3. READ ONE Supplier by ID (GET /api/bank/suppliers/:id)
router.get('/suppliers/:id', async (req, res) => {
    try {
        const supplier = await Supplier.findById(req.params.id);
        if (!supplier) {
            return res.status(404).json({ message: 'Supplier not found' });
        }
        res.json(supplier);
    } catch (err) {
        // Handles cases where the ID format is invalid (e.g., not an ObjectId)
        res.status(500).json({ message: 'Error retrieving supplier: ' + err.message });
    }
});

// 4. UPDATE a Supplier (PUT /api/bank/suppliers/:id)
router.put('/suppliers/:id', async (req, res) => {
    try {
        const updatedSupplier = await Supplier.findByIdAndUpdate(
            req.params.id,
            req.body,
            { new: true, runValidators: true } // { new: true } returns the updated document, { runValidators: true } ensures Mongoose runs validation checks
        );

        if (!updatedSupplier) {
            return res.status(404).json({ message: 'Supplier not found' });
        }
        res.json(updatedSupplier);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

// 5. DELETE a Supplier (DELETE /api/bank/suppliers/:id)
router.delete('/suppliers/:id', async (req, res) => {
    try {
        const result = await Supplier.findByIdAndDelete(req.params.id);
        if (!result) {
            return res.status(404).json({ message: 'Supplier not found' });
        }
        // Send a 204 No Content status for a successful deletion
        res.status(204).send(); 
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// Test endpoint (optional, good for checking the router is loaded)
router.get('/', (req, res) => {
    res.send('Bank routes working 🚀');
});

// Export the router for use in app.js
module.exports = router;