const express = require('express');
const Purchase = require('../models/purchases');
const router = express.Router();

// Helper: compute total cost if not provided or inconsistent
function computeTotal(quantity, unitPrice) {
  const q = Number(quantity) || 0;
  const u = Number(unitPrice) || 0;
  return q * u;
}

/*
  POST /api/purchases
  Body (JSON):
  {
    "supplier": { "name": "ABC", "phone": "012345" },
    "itemType": "Fertilizer",
    "quantity": 10,
    "unitPrice": 25.5,
    // optional: "totalCost": 255
    // farmerId optional if set by auth middleware
  }
*/
router.post('/', async (req, res) => {
  try {
    const { farmerId, supplier, itemType, quantity, unitPrice } = req.body;

    if (!farmerId || !supplier || !supplier.name || !supplier.phone ||
        !itemType || !quantity || !unitPrice) {
      return res.status(400).json({ message: 'Missing required fields' });
    }

    const totalCost = quantity * unitPrice;

    const purchase = new Purchase({
      farmerId,
      supplier,
      itemType,
      quantity,
      unitPrice,
      totalCost,
      // date will auto default
    });

    const saved = await purchase.save();
    res.status(201).json(saved);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
});

/*
  GET /api/purchases
  Query params:
    - ?farmerId=<id>  -> get only that farmer's purchases
    - ?limit=20&skip=0 -> pagination
*/
router.get('/', async (req, res) => {
  try {
    const { farmerId, limit = 50, skip = 0 } = req.query;
    const filter = {};
    if (farmerId) filter.farmerId = farmerId;
    // if you want to use authenticated farmer: filter.farmerId = req.user.id

    const purchases = await Purchase.find(filter)
      .sort({ date: -1 })
      .skip(Number(skip))
      .limit(Number(limit));

    return res.json(purchases);
  } catch (err) {
    console.error('GET /api/purchases error', err);
    return res.status(500).json({ message: 'Server error' });
  }
});

/*
  GET /api/purchases/:id
*/
router.get('/:id', async (req, res) => {
  try {
    const p = await Purchase.findById(req.params.id);
    if (!p) return res.status(404).json({ message: 'Purchase not found' });
    return res.json(p);
  } catch (err) {
    console.error('GET /api/purchases/:id error', err);
    return res.status(500).json({ message: 'Server error' });
  }
});

/*
  PUT /api/purchases/:id
  Updates allowed fields: supplier, itemType, quantity, unitPrice, totalCost
  Recomputes totalCost if quantity or unitPrice changed and totalCost not provided.
*/
router.put('/:id', async (req, res) => {
  try {
    const update = {};
    const allowed = ['supplier', 'itemType', 'quantity', 'unitPrice', 'totalCost'];
    allowed.forEach(field => {
      if (req.body[field] !== undefined) update[field] = req.body[field];
    });

    // if quantity or unitPrice changed and totalCost not provided -> recalc
    if ((update.quantity !== undefined || update.unitPrice !== undefined) && update.totalCost === undefined) {
      // get existing to compute defaults
      const existing = await Purchase.findById(req.params.id);
      if (!existing) return res.status(404).json({ message: 'Purchase not found' });
      const q = update.quantity !== undefined ? update.quantity : existing.quantity;
      const u = update.unitPrice !== undefined ? update.unitPrice : existing.unitPrice;
      update.totalCost = computeTotal(q, u);
    }

    const updated = await Purchase.findByIdAndUpdate(req.params.id, update, { new: true });
    if (!updated) return res.status(404).json({ message: 'Purchase not found' });
    return res.json(updated);
  } catch (err) {
    console.error('PUT /api/purchases/:id error', err);
    return res.status(500).json({ message: 'Server error' });
  }
});

/*
  DELETE /api/purchases/:id
*/
router.delete('/:id', async (req, res) => {
  try {
    const removed = await Purchase.findByIdAndDelete(req.params.id);
    if (!removed) return res.status(404).json({ message: 'Purchase not found' });
    return res.json({ message: 'Deleted', id: removed._id });
  } catch (err) {
    console.error('DELETE /api/purchases/:id error', err);
    return res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;