const express = require('express');
const router = express.Router();
const Sale = require('../models/sales');


// =========================
// CREATE a new sale (POST)
// POST /api/sales
// =========================
router.post('/', async (req, res) => {
  try {
    const { farmerId, productType, quantity, pricePerUnit } = req.body;

    // Validate required fields
    if (!farmerId || !productType || quantity == null || pricePerUnit == null) {
      return res.status(400).json({
        message: 'farmerId, productType, quantity, pricePerUnit are required',
      });
    }

    const qty = Number(quantity);
    const price = Number(pricePerUnit);

    if (isNaN(qty) || isNaN(price) || qty <= 0 || price <= 0) {
      return res.status(400).json({
        message: 'quantity and pricePerUnit must be positive numbers',
      });
    }

    const totalPrice = qty * price;

    const newSale = new Sale({
      farmerId,
      productType,
      quantity: qty,
      pricePerUnit: price,
      totalPrice,
    });

    const savedSale = await newSale.save();
    return res.status(201).json(savedSale);
  } catch (err) {
    console.error('Error creating sale:', err);
    return res.status(500).json({ message: 'Server error' });
  }
});


// =========================
// READ ALL sales (GET)
// GET /api/sales
// =========================
router.get('/', async (req, res) => {
  try {
    const sales = await Sale.find();
    return res.json(sales);
  } catch (err) {
    console.error('Error fetching sales:', err);
    return res.status(500).json({ message: 'Server error' });
  }
});


// =========================
// READ ONE sale by ID (GET)
// GET /api/sales/:id
// =========================
router.get('/:id', async (req, res) => {
  try {
    const sale = await Sale.findById(req.params.id);

    if (!sale) {
      return res.status(404).json({ message: 'Sale not found' });
    }

    return res.json(sale);
  } catch (err) {
    console.error('Error fetching sale:', err);
    return res.status(500).json({ message: 'Server error' });
  }
});


// =========================
// UPDATE sale (PUT)
// PUT /api/sales/:id
// =========================
router.put('/:id', async (req, res) => {
  try {
    const { productType, quantity, pricePerUnit } = req.body;

    const updatedFields = {};

    if (productType) updatedFields.productType = productType;
    if (quantity != null) updatedFields.quantity = Number(quantity);
    if (pricePerUnit != null) updatedFields.pricePerUnit = Number(pricePerUnit);

    // Recalculate totalPrice if quantity or price changed
    if (
      updatedFields.quantity != null &&
      updatedFields.pricePerUnit != null
    ) {
      updatedFields.totalPrice =
        updatedFields.quantity * updatedFields.pricePerUnit;
    }

    const updatedSale = await Sale.findByIdAndUpdate(
      req.params.id,
      updatedFields,
      { new: true }
    );

    if (!updatedSale) {
      return res.status(404).json({ message: 'Sale not found' });
    }

    return res.json(updatedSale);
  } catch (err) {
    console.error('Error updating sale:', err);
    return res.status(500).json({ message: 'Server error' });
  }
});


// =========================
// DELETE sale (DELETE)
// DELETE /api/sales/:id
// =========================
router.delete('/:id', async (req, res) => {
  try {
    const deletedSale = await Sale.findByIdAndDelete(req.params.id);

    if (!deletedSale) {
      return res.status(404).json({ message: 'Sale not found' });
    }

    return res.json({ message: 'Sale deleted successfully' });
  } catch (err) {
    console.error('Error deleting sale:', err);
    return res.status(500).json({ message: 'Server error' });
  }
});


module.exports = router;