require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');

const authRoutes = require('./routes/auth');
const purchaseRoutes = require('./routes/purchases');
const saleRoutes = require('./routes/sales');
const loanRoutes = require('./routes/loanRequests');
const summaryRoutes = require('./routes/summary');
const bankRoutes = require('./routes/bank');

const app = express();
app.use(express.json());

mongoose.connect(process.env.MONGO_URI)
  .then(() => {
    console.log('MongoDB connected');
    // Start server after DB connection
    // const express = require('express');
    // const app = express();
  })
  .catch(err => console.error('MongoDB connection error:', err))
  
// Routes
app.use('/api/auth', authRoutes);
app.use('/api/purchases', purchaseRoutes);
app.use('/api/sales', saleRoutes);
app.use('/api/loans', loanRoutes);
app.use('/api/summary', summaryRoutes);
app.use('/api/bank', bankRoutes);

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
