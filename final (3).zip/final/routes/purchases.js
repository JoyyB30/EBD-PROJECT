const express = require('express');
const Purchase = require('../models/Purchases');
const router = express.Router();

// CREATE purchase
router.post('/', async (req, res) => {
  try {
    const { farmerId, supplierId, itemType, quantity, unitPrice } = req.body;
    const totalCost = quantity * unitPrice;

    const purchase = new Purchase({
      farmerId,
      supplierId,
      itemType,
      quantity,
      unitPrice,
      totalCost
    });

    await purchase.save();
    res.status(201).json(purchase);

  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET all purchases for a farmer  
router.get('/farmer/:farmerId', async (req, res) => {
  try {
    const purchases = await Purchase
      .find({ farmerId: req.params.farmerId })
      .sort({ date: -1 });

    res.json(purchases);

  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// UPDATE purchase by ID
router.put('/:id', async (req, res) => {
  try {
    const { supplierId, itemType, quantity, unitPrice } = req.body;

    let totalCost;
    if (quantity !== undefined && unitPrice !== undefined) {
      totalCost = quantity * unitPrice;
    }

    const updatedPurchase = await Purchase.findByIdAndUpdate(
      req.params.id,
      {
        supplierId,
        itemType,
        quantity,
        unitPrice,
        ...(totalCost !== undefined && { totalCost })
      },
      { new: true }
    );

    if (!updatedPurchase) {
      return res.status(404).json({ message: 'Purchase not found' });
    }

    res.json(updatedPurchase);

  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// DELETE purchase by ID
router.delete('/:id', async (req, res) => {
  try {
    const deleted = await Purchase.findByIdAndDelete(req.params.id);

    if (!deleted) {
      return res.status(404).json({ message: 'Purchase not found' });
    }

    res.json({ message: 'Purchase deleted successfully' });

  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;