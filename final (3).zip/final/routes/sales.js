const express = require('express');
const Sale = require('../models/Sale');
const router = express.Router();

// CREATE sale
router.post('/', async (req, res) => {
  try {
    const { farmerId, productType, quantity, unitPrice } = req.body;
    const totalAmount = quantity * unitPrice;

    const sale = new Sale({
      farmerId,
      productType,
      quantity,
      unitPrice,
      totalAmount
    });

    await sale.save();
    res.status(201).json(sale);

  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET all sales for a farmer  
router.get('/farmer/:farmerId', async (req, res) => {
  try {
    const sales = await Sale
      .find({ farmerId: req.params.farmerId })
      .sort({ date: -1 });

    res.json(sales);

  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// UPDATE sale by ID
router.put('/:id', async (req, res) => {
  try {
    const { productType, quantity, unitPrice } = req.body;

    let totalAmount;
    if (quantity !== undefined && unitPrice !== undefined) {
      totalAmount = quantity * unitPrice;
    }

    const updatedSale = await Sale.findByIdAndUpdate(
      req.params.id,
      {
        productType,
        quantity,
        unitPrice,
        ...(totalAmount !== undefined && { totalAmount })
      },
      { new: true }
    );

    if (!updatedSale) {
      return res.status(404).json({ message: 'Sale not found' });
    }

    res.json(updatedSale);

  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// DELETE sale by ID
router.delete('/:id', async (req, res) => {
  try {
    const deletedSale = await Sale.findByIdAndDelete(req.params.id);

    if (!deletedSale) {
      return res.status(404).json({ message: 'Sale not found' });
    }

    res.json({ message: 'Sale deleted successfully' });

  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;