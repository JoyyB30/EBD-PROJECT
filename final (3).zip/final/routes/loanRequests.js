const express = require('express');
const LoanRequest = require('../models/LoanRequest');
const router = express.Router();

// CREATE loan request
router.post('/', async (req, res) => {
  try {
    const { farmerId, nationalID, approvedAmount } = req.body;
    const loan = new LoanRequest({ farmerId, nationalID, approvedAmount });
    await loan.save();
    res.status(201).json(loan);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET all loan requests
router.get('/', async (req, res) => {
  try {
    const loans = await LoanRequest.find().sort({ dateRequested: -1 });
    res.json(loans);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET loan by ID (missing before)
// GET a single loan by ID

router.get('/:id', async (req, res) => {
  try {
    const loan = await LoanRequest.findById(req.params.id);
    if (!loan) return res.status(404).json({ message: 'Loan not found' });
    res.json(loan);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// UPDATE loan
router.put('/:id', async (req, res) => {
  try {
    const { status, approvedAmount } = req.body;
    const loan = await LoanRequest.findByIdAndUpdate(
      req.params.id,
      { status, approvedAmount },
      { new: true }
    );
    res.json(loan);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

router.delete('/:id', async (req, res) => {
  try {
    const loan = await LoanRequest.findByIdAndDelete(req.params.id);
    if (!loan) return res.status(404).json({ message: 'Loan not found' });
    res.json({ message: 'Loan deleted successfully' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
